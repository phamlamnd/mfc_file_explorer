#include "stdafx.h"
#include "C_Pentagon.h"
void C_Pentagon::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;

	CRect r = getBoundingRect();
	CPoint TPoint[5];
	switch (m_nRotTime)
	{
	case 0:
	{
		
		TPoint[0].SetPoint(r.left, (r.top + r.bottom) / 2);
		TPoint[1].SetPoint((3 * r.left + r.right) / 4, r.bottom);
		TPoint[2].SetPoint((r.left + 3 * r.right) / 4, r.bottom);
		TPoint[3].SetPoint(r.right, (r.top + r.bottom) / 2);
		TPoint[4].SetPoint((r.right + r.left) / 2, r.top);
	}
	break;
	case 1:
	{
		TPoint[0].SetPoint((r.left+r.right)/2,r.top);
		TPoint[1].SetPoint(r.left, (3*r.top + r.bottom) / 4);
		TPoint[2].SetPoint(r.left, (r.top + 3 * r.bottom) / 4);
		TPoint[3].SetPoint((r.left + r.right) / 2, r.bottom);
		TPoint[4].SetPoint(r.right, (r.top + r.bottom) / 2);
		break;
	}
	case 2:
	{
		TPoint[0].SetPoint(r.left, (r.top + r.bottom) / 2);
		TPoint[1].SetPoint((3 * r.left + r.right) / 4, r.top);
		TPoint[2].SetPoint((r.left + 3 * r.right) / 4, r.top);
		TPoint[3].SetPoint(r.right, (r.top + r.bottom) / 2);
		TPoint[4].SetPoint((r.right + r.left) / 2, r.bottom);
	}

	break;
	case 3:
	{
		TPoint[0].SetPoint((r.left + r.right) / 2, r.top);
		TPoint[1].SetPoint(r.right, (3 * r.top + r.bottom) / 4);
		TPoint[2].SetPoint(r.right, (r.top + 3 * r.bottom) / 4);
		TPoint[3].SetPoint((r.left + r.right) / 2, r.bottom);
		TPoint[4].SetPoint(r.left, (r.top + r.bottom) / 2);
		break;
	}
	}
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Polygon(TPoint, 5);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
void C_Pentagon::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	CPoint TPoint[5];
	TPoint[0].SetPoint(r.left, (r.top + r.bottom) / 2);
	TPoint[1].SetPoint((3 * r.left + r.right) / 4, r.bottom);
	TPoint[2].SetPoint((r.left + 3 * r.right) / 4, r.bottom);
	TPoint[3].SetPoint(r.right, (r.top + r.bottom) / 2);
	TPoint[4].SetPoint((r.right + r.left) / 2, r.top);
	pMyDc->Polygon(TPoint, 5);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}