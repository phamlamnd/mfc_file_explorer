#pragma once
#include "afxwin.h"


// TextInputDlg dialog

class TextInputDlg : public CDialogEx
{
	DECLARE_DYNAMIC(TextInputDlg)

public:
	TextInputDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~TextInputDlg();
	int getNum();
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_TEXTIN };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString MyText;
	//CEdit m_edt_TextInput;
	CString m_text;
};
