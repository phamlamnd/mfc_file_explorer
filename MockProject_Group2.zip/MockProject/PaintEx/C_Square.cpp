#include "stdafx.h"
#include "C_Square.h"
void C_Square::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;

	CRect r = getBoundingRect();
	m_BoundingRect.bottom = m_BoundingRect.top + (m_BoundingRect.right - m_BoundingRect.left);
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	else
	{
		NewPen.CreatePenIndirect(&m_MyLogPen);
		NewBrush.CreateBrushIndirect(&m_MyLogBrush);
		CPen* pOldPen = pMyDc->SelectObject(&NewPen);
		CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
		pMyDc->Rectangle(&m_BoundingRect);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from device context
	}
}
void C_Square::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	m_BoundingRect.bottom = m_BoundingRect.top + (m_BoundingRect.right - m_BoundingRect.left);
	pMyDc->Rectangle(&m_BoundingRect);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
