
// PaintExView.h : interface of the CPaintExView class
//

#pragma once
#include <iostream>
#include <vector>
#include "C_Ellipse.h"
#include "C_Line.h"
#include "C_Pentagon.h"
#include "C_Rectangle.h"
#include "C_Triangle.h"
#include "C_Square.h"
#include "RoundedRect.h"
#include "C_Cirle.h"
#include "C_Hexagonal.h"
#include "C_Diamond.h"
#include "C_Text.h"
#include "TextInputDlg.h"
#include "C_Curve.h"

#define MAX_SHAPES					100
#define SHAPE_RESIZERIGHT_TOP		0
#define SHAPE_RESIZELEFT_TOP		1
#define SHAPE_RESIZERIGHT_BOTTOM	2
#define SHAPE_RESIZELEFT_BOTTOM		3
#define SHAPE_SELECT				4
#define SHAPE_DRAG					5
#define SHAPE_NEW					6
#define SHAPE_DONOTHING				7

class CPaintExView : public CView
{
protected: // create from serialization only
	CPaintExView();
	DECLARE_DYNCREATE(CPaintExView)

// Attributes
public:
	CPaintExDoc* GetDocument() const;
	CPoint locationPoint;
	bool m_bDelete;
	bool m_bOnPen;
	bool m_bOnBrush;
	bool m_bChosingMode;
	bool m_bResize;
	bool m_bRot;
// Operations
public:
	enum EnumShape { eRectangle, eEllipse, eTriangle, ePentagon, eLine, eSquare, eHexagonal, eCirle, eDiamond, eRoundRect,eText, eCurve };
// Overrides
public:
	void OnInitialUpdate();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CPaintExView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:


	//hinh & mau
	afx_msg void OnButtonred();
	afx_msg void OnUpdateButtonred(CCmdUI *pCmdUI);
	afx_msg void OnButtonblue();
	afx_msg void OnUpdateButtonblue(CCmdUI *pCmdUI);
	afx_msg void OnButtongreen();
	afx_msg void OnUpdateButtongreen(CCmdUI *pCmdUI);
	afx_msg void OnButtonpurple();
	afx_msg void OnUpdateButtonpurple(CCmdUI *pCmdUI);
	afx_msg void OnButtonblack();
	afx_msg void OnUpdateButtonblack(CCmdUI *pCmdUI);
	afx_msg void OnButtonhue();
	afx_msg void OnUpdateButtonhue(CCmdUI *pCmdUI);
	afx_msg void OnButtonwhite();
	afx_msg void OnUpdateButtonwhite(CCmdUI *pCmdUI);
	afx_msg void OnShapecircle();
	afx_msg void OnUpdateShapecircle(CCmdUI *pCmdUI);
	afx_msg void OnShapediamond();
	afx_msg void OnUpdateShapediamond(CCmdUI *pCmdUI);
	afx_msg void OnShapeelip();
	afx_msg void OnUpdateShapeelip(CCmdUI *pCmdUI);
	afx_msg void OnShapehexagon();
	afx_msg void OnUpdateShapehexagon(CCmdUI *pCmdUI);
	afx_msg void OnShapeline();
	afx_msg void OnUpdateShapeline(CCmdUI *pCmdUI);
	afx_msg void OnShapepentagon();
	afx_msg void OnUpdateShapepentagon(CCmdUI *pCmdUI);
	afx_msg void OnShaperoundrect();
	afx_msg void OnUpdateShaperoundrect(CCmdUI *pCmdUI);
	afx_msg void OnShapesquare();
	afx_msg void OnUpdateShapesquare(CCmdUI *pCmdUI);
	afx_msg void OnShapetriangle();
	afx_msg void OnUpdateShapetriangle(CCmdUI *pCmdUI);
	afx_msg void OnShaperect();
	afx_msg void OnUpdateShaperect(CCmdUI *pCmdUI);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnColorbrush();
	afx_msg void OnUpdateColorbrush(CCmdUI *pCmdUI);
	afx_msg void OnColorpen();
	afx_msg void OnUpdateColorpen(CCmdUI *pCmdUI);
	afx_msg void OnColorfill();
	afx_msg void OnModTrash();
	afx_msg void OnUpdateModTrash(CCmdUI *pCmdUI);
	afx_msg void OnShapetext();
	afx_msg void OnUpdateShapetext(CCmdUI *pCmdUI);
	afx_msg void OnModChoose();
	afx_msg void OnUpdateModChoose(CCmdUI *pCmdUI);
	afx_msg void OnModResize();
	afx_msg void OnUpdateModResize(CCmdUI *pCmdUI);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnModDrag();
	afx_msg void OnUpdateModDrag(CCmdUI *pCmdUI);
	afx_msg void OnUpdateColorfill(CCmdUI *pCmdUI);
	afx_msg void OnModRotate();
	afx_msg void OnUpdateModRotate(CCmdUI *pCmdUI);
	afx_msg void OnShapecurve();
	afx_msg void OnUpdateShapecurve(CCmdUI *pCmdUI);
	afx_msg void OnUpdateIndicatorPos(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushDashdot();
	afx_msg void OnUpdatePenbrushDashdot(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushDot();
	afx_msg void OnUpdatePenbrushDot(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushHatch2();
	afx_msg void OnUpdatePenbrushHatch2(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushHatch3();
	afx_msg void OnUpdatePenbrushHatch3(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushHatch1();
	afx_msg void OnUpdatePenbrushHatch1(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushWidth1();
	afx_msg void OnUpdatePenbrushWidth1(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushWidth2();
	afx_msg void OnUpdatePenbrushWidth2(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushWidth3();
	afx_msg void OnUpdatePenbrushWidth3(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushDash();
	afx_msg void OnUpdatePenbrushDash(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushSolidpen();
	afx_msg void OnUpdatePenbrushSolidpen(CCmdUI *pCmdUI);
	afx_msg void OnPenbrushBrushsolid();
	afx_msg void OnUpdatePenbrushBrushsolid(CCmdUI *pCmdUI);
};

#ifndef _DEBUG  // debug version in PaintExView.cpp
inline CPaintExDoc* CPaintExView::GetDocument() const
   { return reinterpret_cast<CPaintExDoc*>(m_pDocument); }
#endif

