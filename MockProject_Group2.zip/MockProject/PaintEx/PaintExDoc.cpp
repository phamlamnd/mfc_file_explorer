
// PaintExDoc.cpp : implementation of the CPaintExDoc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "PaintEx.h"
#endif

#include "PaintExDoc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPaintExDoc

IMPLEMENT_DYNCREATE(CPaintExDoc, CDocument)

BEGIN_MESSAGE_MAP(CPaintExDoc, CDocument)
END_MESSAGE_MAP()


// CPaintExDoc construction/destruction

CPaintExDoc::CPaintExDoc()
{
	// TODO: add one-time construction code here

}

CPaintExDoc::~CPaintExDoc()
{
}

BOOL CPaintExDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	
	if (m_apShapen.size() > 0)
	{
		std::vector<C_Shape*>::iterator it = m_apShapen.end();
		it--;
		for (; it >= m_apShapen.begin(); --it)
		{
			delete (*it);
			if (it == m_apShapen.begin())
				break;
		}
		m_apShapen.clear();
	}
	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CPaintExDoc serialization

void CPaintExDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		auto it = m_apShapen.begin();
		int count = m_apShapen.size();
		ar << count;

		for (; it != m_apShapen.end(); ++it)
		{
			ar << (*it)->getShapeID()<< (*it)->getBoundingRect() << (*it)->getLogPen().lopnColor << (*it)->getLogPen().lopnStyle << (*it)->getLogPen().lopnWidth
				<< (*it)->getLogBrush().lbColor << (*it)->getLogBrush().lbHatch << (*it)->getLogBrush().lbStyle;
			if ((*it)->getShapeID() == 10)
				ar << (*it)->getDisplayedString();
			if ((*it)->getShapeID() == 3)
			{
				ar << (*it)->getStart() << (*it)->getEnd();
			}
		}
	}
	else
	{
		// TODO: add loading code here
		int count, type;
		ar >> count;
		m_apShapen.clear();
		auto it = m_apShapen.begin();
		for (int i = 0; i < count; ++i)
		{
			C_Shape *pShape = NULL;
			ar >> type;
			switch (type)
			{
			case 0:
				pShape = new C_Rectangle;
				break;
			case 1:
				pShape = new C_Ellipse;
				break;
			case 2:
				pShape = new C_Triangle;
				break;
			case 3:
				pShape = new C_Line;
				break;
			case 4:
				pShape = new C_Diamond;
				break;
			case 5:
				pShape = new C_Hexagonal;
				break;
			case 6:
				pShape = new C_Pentagon;
				break;
			case 7:
				pShape = new C_Cirle;
				break;
			case 8:
				pShape = new C_Square;
				break;
			case 9:
				pShape = new C_RoundedRect;
				break;
			case 10:
				pShape = new C_Text;
				break;
			case 11:
				pShape = new C_Curve;
			}
			CRect rect;
			ar >> rect;
			pShape->setBoundingRect(rect);
			COLORREF penColor;
			UINT penStyle;
			POINT penWidth;
			ar >> penColor;
			ar >> penStyle;
			ar >> penWidth;
			pShape->setPen(penColor, penStyle, penWidth);
			COLORREF brushColor;
			ULONG brushHatch;
			UINT brushStyle;
			ar >> brushColor;
			ar >> brushHatch;
			ar >> brushStyle;
			pShape->setBrush(brushColor, brushColor, brushStyle);
			if (type == 10)
			{
				CString displayedString;
				ar >> displayedString;
				pShape->setDisplayedString(displayedString);
			}
			if (type == 3)
			{
				CPoint start, end;
				ar >> start >> end;
				pShape->setStart(start);
				pShape->setEnd(end);
			}
			m_apShapen.push_back(pShape);
		}
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CPaintExDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CPaintExDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CPaintExDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CPaintExDoc diagnostics

#ifdef _DEBUG
void CPaintExDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPaintExDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CPaintExDoc commands
