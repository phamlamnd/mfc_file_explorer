#pragma once
#include "C_Shape.h"
class C_Text :
	public C_Shape
{
public:
	void setDisplayedString(CString str);
	CString getDisplayedString();
	C_Text();
    ~C_Text();
	void draw(CDC *pMyDc);
	void drawNew(CDC *pMyDc);
};

