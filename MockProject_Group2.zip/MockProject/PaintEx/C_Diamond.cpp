#include "stdafx.h"
#include "C_Diamond.h"


void C_Diamond::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	CRect r = getBoundingRect();
	CPoint TPoints[4];
	TPoints[0].SetPoint(r.left, (r.top + r.bottom) / 2);
	TPoints[1].SetPoint((r.left + r.right) / 2, r.top);
	TPoints[2].SetPoint(r.right, (r.top + r.bottom) / 2);
	TPoints[3].SetPoint((r.left + r.right) / 2, r.bottom);
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Polygon(TPoints, 4);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	//pMyDc->SelectObject(pOldBrush); // from device context
}
void C_Diamond::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	CPoint TPoints[4];
	TPoints[0].SetPoint(r.left, (r.top + r.bottom) / 2);
	TPoints[1].SetPoint((r.left + r.right) / 2, r.top);
	TPoints[2].SetPoint(r.right, (r.top + r.bottom) / 2);
	TPoints[3].SetPoint((r.left + r.right) / 2, r.bottom);
	pMyDc->Polygon(TPoints, 4);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
