#include "stdafx.h"
#include "C_Rectangle.h"

void C_Rectangle::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	else
	{
		NewPen.CreatePenIndirect(&m_MyLogPen);
		NewBrush.CreateBrushIndirect(&m_MyLogBrush);
		CPen* pOldPen = pMyDc->SelectObject(&NewPen);
		CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
		pMyDc->Rectangle(&m_BoundingRect);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from device context
		pOldBrush->DeleteObject();
		pOldPen->DeleteObject();
	}
}
void C_Rectangle::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Rectangle(&m_BoundingRect);
	pMyDc->SelectObject(pOldPen);
	pMyDc->SelectObject(pOldBrush);
	pOldBrush->DeleteObject();
	pOldPen->DeleteObject();
}