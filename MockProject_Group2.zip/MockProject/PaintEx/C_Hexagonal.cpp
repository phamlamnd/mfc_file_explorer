#include "stdafx.h"
#include "C_Hexagonal.h"

void C_Hexagonal::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	
	CRect r = getBoundingRect();
	CPoint hexagonalPoints[6];
	switch (m_nRotTime)
	{
	case 0:
	{
		hexagonalPoints[0].SetPoint(r.left, (3 * r.bottom + r.top) / 4);
		hexagonalPoints[1].SetPoint((r.right + r.left) / 2, r.bottom);
		hexagonalPoints[2].SetPoint(r.right, (3 * r.bottom + r.top) / 4);
		hexagonalPoints[3].SetPoint(r.right, (3 * r.top + r.bottom) / 4);
		hexagonalPoints[4].SetPoint((r.left + r.right) / 2, r.top);
		hexagonalPoints[5].SetPoint(r.left, (3 * r.top + r.bottom) / 4);
	}
	break;
	case 1:
	{
		hexagonalPoints[0].SetPoint((3*r.left+r.right)/4, r.top);
		hexagonalPoints[1].SetPoint(r.left, (r.bottom+r.top)/2);
		hexagonalPoints[2].SetPoint((3 * r.left + r.right) / 4, r.bottom);
		hexagonalPoints[3].SetPoint((r.left + 3*r.right) / 4, r.bottom);
		hexagonalPoints[4].SetPoint(r.right, (r.bottom + r.top) / 2);
		hexagonalPoints[5].SetPoint((r.left + 3 * r.right) / 4, r.top);
	}
	break;
	case 2:
	{
		hexagonalPoints[0].SetPoint(r.left, (3 * r.bottom + r.top) / 4);
		hexagonalPoints[1].SetPoint((r.right + r.left) / 2, r.bottom);
		hexagonalPoints[2].SetPoint(r.right, (3 * r.bottom + r.top) / 4);
		hexagonalPoints[3].SetPoint(r.right, (3 * r.top + r.bottom) / 4);
		hexagonalPoints[4].SetPoint((r.left + r.right) / 2, r.top);
		hexagonalPoints[5].SetPoint(r.left, (3 * r.top + r.bottom) / 4);
	}
	break;
	case 3:
	{
		hexagonalPoints[0].SetPoint((3 * r.left + r.right) / 4, r.top);
		hexagonalPoints[1].SetPoint(r.left, (r.bottom + r.top) / 2);
		hexagonalPoints[2].SetPoint((3 * r.left + r.right) / 4, r.bottom);
		hexagonalPoints[3].SetPoint((r.left + 3 * r.right) / 4, r.bottom);
		hexagonalPoints[4].SetPoint(r.right, (r.bottom + r.top) / 2);
		hexagonalPoints[5].SetPoint((r.left + 3 * r.right) / 4, r.top);
	}
	break;
	}
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Polygon(hexagonalPoints, 6);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
void C_Hexagonal::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	CPoint hexagonalPoints[6];
	hexagonalPoints[0].SetPoint(r.left, (3 * r.bottom + r.top) / 4);
	hexagonalPoints[1].SetPoint((r.right + r.left) / 2, r.bottom);
	hexagonalPoints[2].SetPoint(r.right, (3 * r.bottom + r.top) / 4);
	hexagonalPoints[3].SetPoint(r.right, (3 * r.top + r.bottom) / 4);
	hexagonalPoints[4].SetPoint((r.left + r.right) / 2, r.top);
	hexagonalPoints[5].SetPoint(r.left, (3 * r.top + r.bottom) / 4);
	pMyDc->Polygon(hexagonalPoints, 6);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}