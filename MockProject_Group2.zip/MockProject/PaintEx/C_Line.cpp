#include "stdafx.h"
#include "C_Line.h"

void C_Line::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	CRect r = getBoundingRect();
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->MoveTo(m_Start);
	pMyDc->LineTo(m_End);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
	pOldBrush->DeleteObject();
	pOldPen->DeleteObject();
}

void C_Line::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	pMyDc->MoveTo(m_Start);
	pMyDc->LineTo(m_End);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
	pOldBrush->DeleteObject();
	pOldPen->DeleteObject();
}