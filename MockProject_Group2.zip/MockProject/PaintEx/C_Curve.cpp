#include "stdafx.h"
#include "C_Curve.h"


void C_Curve::drawNew(CDC *pMyDc, CPoint point1, CPoint point2)
{
	if (m_nthRepair == 0) {
		Point1 = Point2 = point1;
		Point4 = Point3 = point2;
		m_BoundingRect.TopLeft() = Point1;
		m_BoundingRect.BottomRight() = Point4;
	}
	if (m_nthRepair == 1) {
		DelPoint2x = m_Current.x - Point1.x;
		DelPoint2y = m_Current.y - Point1.y;

	}
	if (m_nthRepair == 2) {
		DelPoint3x = Point4.x - m_Current.x;
		DelPoint3y = Point4.y - m_Current.y;

	}
	if (m_nthRepair > 2) {
		Point1 = m_BoundingRect.TopLeft();
		Point4 = m_BoundingRect.BottomRight();
	}
	Point2.x = Point1.x + DelPoint2x;
	Point2.y = Point1.y + DelPoint2y;
	Point3.x = Point4.x - DelPoint3x;
	Point3.y = Point4.y - DelPoint3y;

	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	//CRect r = GetBoundingRect();
	CPoint TPoints[4];
	TPoints[0] = Point1;
	TPoints[1] = Point2;
	TPoints[2] = Point3;
	TPoints[3] = Point4;
	pMyDc->PolyBezier(TPoints, 4);

	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}