// TextInputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PaintEx.h"
#include "TextInputDlg.h"
#include "afxdialogex.h"


// TextInputDlg dialog

IMPLEMENT_DYNAMIC(TextInputDlg, CDialogEx)

TextInputDlg::TextInputDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_TEXTIN, pParent)
	, m_text(_T(""))
{

}

TextInputDlg::~TextInputDlg()
{
}

void TextInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//DDX_Control(pDX, IDC_EDIT1, m_edt_TextInput);
	DDX_Text(pDX, IDC_EDIT1, m_text);
}

int TextInputDlg::getNum()
{
	return 10;
}
BEGIN_MESSAGE_MAP(TextInputDlg, CDialogEx)
END_MESSAGE_MAP()


// TextInputDlg message handlers
