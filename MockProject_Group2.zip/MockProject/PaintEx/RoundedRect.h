#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_RoundedRect :
	public C_Shape
{
public:
	C_RoundedRect()
	{
		m_nRotTime = 0;
		m_ShapeID = 9;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};

