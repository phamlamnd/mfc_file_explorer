
// PaintExView.cpp : implementation of the CPaintExView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "PaintEx.h"
#endif

#include "PaintExDoc.h"
#include "PaintExView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPaintExView

IMPLEMENT_DYNCREATE(CPaintExView, CView)

BEGIN_MESSAGE_MAP(CPaintExView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CPaintExView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_BUTTONRED, &CPaintExView::OnButtonred)
	ON_UPDATE_COMMAND_UI(ID_BUTTONRED, &CPaintExView::OnUpdateButtonred)
	ON_COMMAND(ID_BUTTONBLUE, &CPaintExView::OnButtonblue)
	ON_UPDATE_COMMAND_UI(ID_BUTTONBLUE, &CPaintExView::OnUpdateButtonblue)
	ON_COMMAND(ID_BUTTONGREEN, &CPaintExView::OnButtongreen)
	ON_UPDATE_COMMAND_UI(ID_BUTTONGREEN, &CPaintExView::OnUpdateButtongreen)
	ON_COMMAND(ID_BUTTONPURPLE, &CPaintExView::OnButtonpurple)
	ON_UPDATE_COMMAND_UI(ID_BUTTONPURPLE, &CPaintExView::OnUpdateButtonpurple)
	ON_COMMAND(ID_BUTTONBLACK, &CPaintExView::OnButtonblack)
	ON_UPDATE_COMMAND_UI(ID_BUTTONBLACK, &CPaintExView::OnUpdateButtonblack)
	ON_COMMAND(ID_BUTTONHUE, &CPaintExView::OnButtonhue)
	ON_UPDATE_COMMAND_UI(ID_BUTTONHUE, &CPaintExView::OnUpdateButtonhue)
	ON_COMMAND(ID_BUTTONWHITE, &CPaintExView::OnButtonwhite)
	ON_UPDATE_COMMAND_UI(ID_BUTTONWHITE, &CPaintExView::OnUpdateButtonwhite)
	ON_COMMAND(ID_SHAPECIRCLE, &CPaintExView::OnShapecircle)
	ON_UPDATE_COMMAND_UI(ID_SHAPECIRCLE, &CPaintExView::OnUpdateShapecircle)
	ON_COMMAND(ID_SHAPEDIAMOND, &CPaintExView::OnShapediamond)
	ON_UPDATE_COMMAND_UI(ID_SHAPEDIAMOND, &CPaintExView::OnUpdateShapediamond)
	ON_COMMAND(ID_SHAPEELIP, &CPaintExView::OnShapeelip)
	ON_UPDATE_COMMAND_UI(ID_SHAPEELIP, &CPaintExView::OnUpdateShapeelip)
	ON_COMMAND(ID_SHAPEHEXAGON, &CPaintExView::OnShapehexagon)
	ON_UPDATE_COMMAND_UI(ID_SHAPEHEXAGON, &CPaintExView::OnUpdateShapehexagon)
	ON_COMMAND(ID_SHAPELINE, &CPaintExView::OnShapeline)
	ON_UPDATE_COMMAND_UI(ID_SHAPELINE, &CPaintExView::OnUpdateShapeline)
	ON_COMMAND(ID_SHAPEPENTAGON, &CPaintExView::OnShapepentagon)
	ON_UPDATE_COMMAND_UI(ID_SHAPEPENTAGON, &CPaintExView::OnUpdateShapepentagon)
	ON_COMMAND(ID_SHAPEROUNDRECT, &CPaintExView::OnShaperoundrect)
	ON_UPDATE_COMMAND_UI(ID_SHAPEROUNDRECT, &CPaintExView::OnUpdateShaperoundrect)
	ON_COMMAND(ID_SHAPESQUARE, &CPaintExView::OnShapesquare)
	ON_UPDATE_COMMAND_UI(ID_SHAPESQUARE, &CPaintExView::OnUpdateShapesquare)
	ON_COMMAND(ID_SHAPETRIANGLE, &CPaintExView::OnShapetriangle)
	ON_UPDATE_COMMAND_UI(ID_SHAPETRIANGLE, &CPaintExView::OnUpdateShapetriangle)
	ON_COMMAND(ID_SHAPERECT, &CPaintExView::OnShaperect)
	ON_UPDATE_COMMAND_UI(ID_SHAPERECT, &CPaintExView::OnUpdateShaperect)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_COLORBRUSH, &CPaintExView::OnColorbrush)
	ON_UPDATE_COMMAND_UI(ID_COLORBRUSH, &CPaintExView::OnUpdateColorbrush)
	ON_COMMAND(ID_COLORPEN, &CPaintExView::OnColorpen)
	ON_UPDATE_COMMAND_UI(ID_COLORPEN, &CPaintExView::OnUpdateColorpen)
	ON_COMMAND(ID_COLORFILL, &CPaintExView::OnColorfill)
	ON_COMMAND(ID_MOD_TRASH, &CPaintExView::OnModTrash)
	ON_UPDATE_COMMAND_UI(ID_MOD_TRASH, &CPaintExView::OnUpdateModTrash)
	ON_COMMAND(ID_SHAPETEXT, &CPaintExView::OnShapetext)
	ON_UPDATE_COMMAND_UI(ID_SHAPETEXT, &CPaintExView::OnUpdateShapetext)
	ON_COMMAND(ID_MOD_CHOOSE, &CPaintExView::OnModChoose)
	ON_UPDATE_COMMAND_UI(ID_MOD_CHOOSE, &CPaintExView::OnUpdateModChoose)
	ON_COMMAND(ID_MOD_RESIZE, &CPaintExView::OnModResize)
	ON_UPDATE_COMMAND_UI(ID_MOD_RESIZE, &CPaintExView::OnUpdateModResize)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_MOD_DRAG, &CPaintExView::OnModDrag)
	ON_UPDATE_COMMAND_UI(ID_MOD_DRAG, &CPaintExView::OnUpdateModDrag)
	ON_UPDATE_COMMAND_UI(ID_COLORFILL, &CPaintExView::OnUpdateColorfill)
	ON_COMMAND(ID_MOD_ROTATE, &CPaintExView::OnModRotate)
	ON_UPDATE_COMMAND_UI(ID_MOD_ROTATE, &CPaintExView::OnUpdateModRotate)
	ON_COMMAND(ID_SHAPECURVE, &CPaintExView::OnShapecurve)
	ON_UPDATE_COMMAND_UI(ID_SHAPECURVE, &CPaintExView::OnUpdateShapecurve)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_POS, &CPaintExView::OnUpdateIndicatorPos)
	ON_COMMAND(ID_ID_PENBRUSH_DASHDOT, &CPaintExView::OnPenbrushDashdot)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_DASHDOT, &CPaintExView::OnUpdatePenbrushDashdot)
	ON_COMMAND(ID_ID_PENBRUSH_DOT, &CPaintExView::OnPenbrushDot)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_DOT, &CPaintExView::OnUpdatePenbrushDot)
	ON_COMMAND(ID_ID_PENBRUSH_HATCH2, &CPaintExView::OnPenbrushHatch2)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_HATCH2, &CPaintExView::OnUpdatePenbrushHatch2)
	ON_COMMAND(ID_ID_PENBRUSH_HATCH3, &CPaintExView::OnPenbrushHatch3)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_HATCH3, &CPaintExView::OnUpdatePenbrushHatch3)
	ON_COMMAND(ID_PENBRUSH_HATCH1, &CPaintExView::OnPenbrushHatch1)
	ON_UPDATE_COMMAND_UI(ID_PENBRUSH_HATCH1, &CPaintExView::OnUpdatePenbrushHatch1)
	ON_COMMAND(ID_ID_PENBRUSH_WIDTH1, &CPaintExView::OnPenbrushWidth1)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_WIDTH1, &CPaintExView::OnUpdatePenbrushWidth1)
	ON_COMMAND(ID_ID_PENBRUSH_WIDTH2, &CPaintExView::OnPenbrushWidth2)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_WIDTH2, &CPaintExView::OnUpdatePenbrushWidth2)
	ON_COMMAND(ID_ID_PENBRUSH_WIDTH3, &CPaintExView::OnPenbrushWidth3)
	ON_UPDATE_COMMAND_UI(ID_ID_PENBRUSH_WIDTH3, &CPaintExView::OnUpdatePenbrushWidth3)
	ON_COMMAND(ID_PENBRUSH_DASH, &CPaintExView::OnPenbrushDash)
	ON_UPDATE_COMMAND_UI(ID_PENBRUSH_DASH, &CPaintExView::OnUpdatePenbrushDash)
	ON_COMMAND(ID_PENBRUSH_SOLIDPEN, &CPaintExView::OnPenbrushSolidpen)
	ON_UPDATE_COMMAND_UI(ID_PENBRUSH_SOLIDPEN, &CPaintExView::OnUpdatePenbrushSolidpen)
	ON_COMMAND(ID_PENBRUSH_BRUSHSOLID, &CPaintExView::OnPenbrushBrushsolid)
	ON_UPDATE_COMMAND_UI(ID_PENBRUSH_BRUSHSOLID, &CPaintExView::OnUpdatePenbrushBrushsolid)
END_MESSAGE_MAP()

// CPaintExView construction/destruction

CPaintExView::CPaintExView()
{
	// TODO: add construction code here

}

CPaintExView::~CPaintExView()
{
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	auto it = pDoc->m_apShapen.begin();
	if (pDoc->m_apShapen.size() > 0)
	{
		it = pDoc->m_apShapen.end();
		--it;
		for (; it >= pDoc->m_apShapen.begin(); --it)
		{
			delete (*it);
			if (it == pDoc->m_apShapen.begin())
			{
				break;
			}
		}
	}
}

BOOL CPaintExView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CPaintExView drawing

void CPaintExView::OnDraw(CDC* pDC)
{
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (pDoc->m_apShapen.size() > 0)
	{
		std::vector<C_Shape*>::iterator it = pDoc->m_apShapen.end();
		--it;
		for (; it >= pDoc->m_apShapen.begin(); --it)
		{
			(*it)->draw(pDC);
			if (it == pDoc->m_apShapen.begin())
			{
				ReleaseDC(pDC);
				break;
			}
		}
	}

	// TODO: add draw code for native data here
}


// CPaintExView printing


void CPaintExView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CPaintExView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPaintExView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPaintExView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CPaintExView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CPaintExView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CPaintExView diagnostics

#ifdef _DEBUG
void CPaintExView::AssertValid() const
{
	CView::AssertValid();
}

void CPaintExView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPaintExDoc* CPaintExView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPaintExDoc)));
	return (CPaintExDoc*)m_pDocument;
}
#endif //_DEBUG


// CPaintExView message handlers
void CPaintExView::OnInitialUpdate()
{
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CView::OnInitialUpdate();
	pDoc->m_bButtonDown = FALSE;
	pDoc->m_BkMode = OPAQUE;
	pDoc->m_LogBrush.lbColor = RGB(255, 255, 255);
	pDoc->m_LogBrush.lbStyle = BS_SOLID;
	pDoc->m_LogPen.lopnColor = RGB(0, 0, 0);
	pDoc->m_LogPen.lopnStyle = PS_SOLID;
	pDoc->m_LogPen.lopnWidth.x = 3;
	pDoc->m_eShapeKind = pDoc->eRectangle;
	pDoc->m_FastRedrawMode = R2_NOTCOPYPEN;
	pDoc->m_bDrawingNewShape = FALSE;
	pDoc->m_bDrag = FALSE;
	m_bDelete = false;
	pDoc->m_bDragMod = FALSE;
	m_bResize = false;
	m_bRot = false;
	pDoc->m_bFill = false;
	m_bChosingMode = false;
	pDoc->m_Text = _T("");
}

void CPaintExView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CDC *pMyDC = this->GetDC();
	auto it = pDoc->m_apShapen.begin();
	auto it2 = pDoc->m_apShapen.begin();
	if (pDoc->m_bFill)
	{

		for (; it != pDoc->m_apShapen.end(); it++)
		{
			if ((*it)->isIn(point))
			{
				(*it)->setParams(&pDoc->m_LogPen, &pDoc->m_LogBrush);
				pDoc->m_RESIZE = SHAPE_DONOTHING;
				return;
			}
		}
	}
	if (m_bDelete)
	{
		for (; it != pDoc->m_apShapen.end(); it++)
		{
			if ((*it)->isIn(point))
			{
				delete (*it);
				pDoc->m_apShapen.erase(it);
				return;
			}
		}
	}
	if(m_bChosingMode)
	{
		for (; it != pDoc->m_apShapen.end(); it++)
		{
			if ((*it)->isIn(point))
			{
				CRect rect = (*it)->getBoundingRect();

				(*it)->setnthRepair();
				(*it)->setCurrentPoint(point);


				pDoc->m_bDrag = TRUE;
				pDoc->m_bButtonDown = TRUE;
				pDoc->m_nDrag = it;
				for (; it2 != pDoc->m_apShapen.end(); it2++)
				{
					(*it2)->m_bChoose = FALSE;
				}
				(*pDoc->m_nDrag)->m_bChoose = TRUE;
				
				if (pDoc->m_bDragMod)
				{
					pDoc->m_RESIZE = SHAPE_DRAG;
					pDoc->m_Start = point;
					(*it)->backingStore(pMyDC);
					return;
				}



				if (m_bRot)
				{
						CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
						CPoint centre = rect.CenterPoint();
						int delY = rect.bottom - rect.top;
						int delX = rect.right - rect.left;
						rect.left = (centre.x - delY / 2);
						rect.right = (centre.x + delY / 2);
						rect.top = (centre.y - delX / 2);
						rect.bottom = (centre.y + delX / 2);
						(*pDoc->m_nDrag)->setBoundingRect(rect);
						if ((*pDoc->m_nDrag)->m_nRotTime == 0)
						{
							(*pDoc->m_nDrag)->setStart(rect.right, rect.top);
							(*pDoc->m_nDrag)->setEnd(rect.left, rect.bottom);
							++(*pDoc->m_nDrag)->m_nRotTime;
						}
						else if ((*pDoc->m_nDrag)->m_nRotTime == 1)
						{
							(*pDoc->m_nDrag)->setStart(rect.right, rect.bottom);
							(*pDoc->m_nDrag)->setEnd(rect.left, rect.top);
							++(*pDoc->m_nDrag)->m_nRotTime;
						}
						else if ((*pDoc->m_nDrag)->m_nRotTime == 2)
						{
							(*pDoc->m_nDrag)->setStart(rect.left, rect.bottom);
							(*pDoc->m_nDrag)->setEnd(rect.right, rect.top);
							++(*pDoc->m_nDrag)->m_nRotTime;
						}
						else if ((*pDoc->m_nDrag)->m_nRotTime == 3)
						{
							(*pDoc->m_nDrag)->setStart(rect.left, rect.top);
							(*pDoc->m_nDrag)->setEnd(rect.right, rect.bottom);
							(*pDoc->m_nDrag)->m_nRotTime = 0;
						}
						pDoc->m_RESIZE = SHAPE_DONOTHING;
					Invalidate();
					return;
				}



				if (m_bResize)
				{

					if (point.x > rect.right - 30 && point.x <rect.right + 30 && point.y > rect.bottom - 30 && point.y < rect.bottom + 30)
					{
						pDoc->m_RESIZE = SHAPE_RESIZERIGHT_BOTTOM;
						pDoc->m_nDrag = it;
						pDoc->m_Start = point;
						(*it)->backingStore(pMyDC);
						return;
					}
					else if (point.x <= rect.right + 30 && point.x >= rect.right - 30 && point.y <= rect.top + 30 && point.y >= rect.top - 30)
					{
						pDoc->m_RESIZE = SHAPE_RESIZERIGHT_TOP;
						pDoc->m_nDrag = it;
						pDoc->m_Start = point;
						(*it)->backingStore(pMyDC);
						return;
					}
					else if (point.x <= rect.left + 30 && point.x >= rect.left - 30 && point.y >= rect.top - 30 && point.y <= rect.top + 30)
					{

						pDoc->m_RESIZE = SHAPE_RESIZELEFT_TOP;
						pDoc->m_nDrag = it;
						pDoc->m_Start = point;
						(*it)->backingStore(pMyDC);
						return;
					}
					else if (point.x <= rect.left + 30 && point.x >= rect.left - 30 && point.y <= rect.bottom + 30 && point.y >= rect.bottom - 30)
					{
						pDoc->m_RESIZE = SHAPE_RESIZELEFT_BOTTOM;
						pDoc->m_nDrag = it;
						pDoc->m_Start = point;
						(*it)->backingStore(pMyDC);
						return;
					}
					else
					{
						pDoc->m_nDrag = it;
						pDoc->m_RESIZE = SHAPE_SELECT;
						pDoc->m_Start = point;
						return;
					}				
				}
			}
			else
			{
				(*it)->m_bChoose = FALSE;
				pDoc->m_bDrag = false;
				pDoc->m_RESIZE = SHAPE_DONOTHING;
				
			}
		}
		pDoc->m_RESIZE = SHAPE_DONOTHING;
		return;
		//return;
	}


	switch (pDoc->m_eShapeKind)
	{
		case eEllipse:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Ellipse);
		}
		break;
		case eTriangle:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Triangle);
		}
		break;
		case ePentagon:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Pentagon);
		}
		break;
		case eLine:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Line);
		}
		break;
		case eSquare:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Square);
		}
		break;
		case eRoundRect:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_RoundedRect);
		}
		break;
		case eCirle:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Cirle);
		}
		break;
		case eHexagonal:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Hexagonal);
		}
		break;
		case eDiamond:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Diamond);
		}
		break;
		case eText:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Text);
			(*pDoc->m_apShapen.begin())->setDisplayedString(pDoc->m_Text);
		}
		break;
		case eCurve: 
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Curve);
		}
		break;
		default:
		{
			auto it = pDoc->m_apShapen.begin();
			pDoc->m_apShapen.insert(it, new C_Rectangle);
		}
	}
	
	std::vector<C_Shape*>::iterator it3 = pDoc->m_apShapen.begin();
	(*it3)->setParams(&pDoc->m_LogPen, &pDoc->m_LogBrush);
	(*it3)->setBoundingRect(point.x, point.y, point.x, point.y);
	(*it3)->backingStore(pMyDC);
	(*it3)->setStart(point);
	(*it3)->setEnd(point);
	pDoc->m_RESIZE = SHAPE_NEW;
	pDoc->m_Start = point;
	pDoc->m_bButtonDown = TRUE;
	pDoc->m_bDrawingNewShape = TRUE;

	SetCapture();
	CView::OnLButtonDown(nFlags, point);
}

void CPaintExView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	locationPoint = point;
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (!pDoc->m_bButtonDown)
		return;
	/*if (m_bChosingMode)
		return;*/
	CDC *pDC = this->GetDC();
	//pDC->SetROP2(pDoc->m_FastRedrawMode);

	if (pDoc->m_RESIZE == SHAPE_RESIZERIGHT_BOTTOM)
	{
		if (m_bResize == TRUE)
		{
			CRect rect = (*pDoc->m_nDrag)->getBoundingRect();


			int DelX = point.x - pDoc->m_Start.x;
			int DelY = point.y - pDoc->m_Start.y;
			if (pDoc->m_bDrawingNewShape)
			{
				(*pDoc->m_nDrag)->undraw(pDC);
				Invalidate();
			}
			int newRight = rect.right + DelX;
			int newBottom = rect.bottom + DelY;
			if (newRight < rect.left)
			{
				newRight = rect.left + 20;
			}
			if (newBottom < rect.top)
			{
				newBottom = rect.top + 20;
			}
			(*pDoc->m_nDrag)->setBoundingRect(rect.left, rect.top, newRight, newBottom);
			(*pDoc->m_nDrag)->backingStore(pDC);
			(*pDoc->m_nDrag)->drawNew(pDC);
			if ((*pDoc->m_nDrag)->getShapeID() == 3)
			{
				if ((*pDoc->m_nDrag)->getStart() == rect.TopLeft())
				{
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().BottomRight());
				}
				else if ((*pDoc->m_nDrag)->getStart() == rect.BottomRight())
				{
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().TopLeft());
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().BottomRight());
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.x += DelX;
					NewEnd.y += DelY;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.y += DelY;
					NewEnd.x += DelX;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
			}
			pDoc->m_bDrawingNewShape = TRUE;

			pDoc->m_Start.x = point.x;
			pDoc->m_Start.y = point.y;
			SetCapture();
			ReleaseDC(pDC);
			return;
		}

		return;
	}
	if (pDoc->m_RESIZE == SHAPE_RESIZERIGHT_TOP)
	{
		if (m_bResize == TRUE)
		{
			CRect rect = (*pDoc->m_nDrag)->getBoundingRect();


			int DelX = point.x - pDoc->m_Start.x;
			int DelY = point.y - pDoc->m_Start.y;
			if (pDoc->m_bDrawingNewShape)
			{
				(*pDoc->m_nDrag)->undraw(pDC);
				Invalidate();
			}
			int newRight = rect.right + DelX;
			int newTop = rect.top + DelY;
			if (newRight < rect.left)
			{
				newRight = rect.left + 20;
			}
			if (newTop > rect.bottom)
			{
				newTop = rect.bottom - 20;
			}
			(*pDoc->m_nDrag)->setBoundingRect(rect.left, newTop, newRight, rect.bottom);
			(*pDoc->m_nDrag)->backingStore(pDC);
			(*pDoc->m_nDrag)->drawNew(pDC);
			pDoc->m_bDrawingNewShape = TRUE;
			if ((*pDoc->m_nDrag)->getShapeID() == 3)
			{
				if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					(*pDoc->m_nDrag)->setStart(
												(*pDoc->m_nDrag)->getBoundingRect().right,
												(*pDoc->m_nDrag)->getBoundingRect().top
											);

					(*pDoc->m_nDrag)->setEnd(
												(*pDoc->m_nDrag)->getBoundingRect().left,
												(*pDoc->m_nDrag)->getBoundingRect().bottom
											);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					(*pDoc->m_nDrag)->setEnd(
												(*pDoc->m_nDrag)->getBoundingRect().right,
												(*pDoc->m_nDrag)->getBoundingRect().top
											);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.y += DelY;
					NewEnd.x += DelX;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.x += DelX;
					NewEnd.y += DelY;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
			}
			pDoc->m_Start.x = point.x;
			pDoc->m_Start.y = point.y;
			SetCapture();
			ReleaseDC(pDC);
			return;
		}

		return;
	}
	if (pDoc->m_RESIZE == SHAPE_RESIZELEFT_TOP)
	{
		if (m_bResize == TRUE)
		{
			CRect rect = (*pDoc->m_nDrag)->getBoundingRect();


			int DelX = point.x - pDoc->m_Start.x;
			int DelY = point.y - pDoc->m_Start.y;
			if (pDoc->m_bDrawingNewShape)
			{
				(*pDoc->m_nDrag)->undraw(pDC);
				Invalidate();
			}
			int newLeft = rect.left + DelX;
			int newTop = rect.top + DelY;
			if (newLeft > rect.right)
			{
				newLeft = rect.right - 20;
			}
			if (newTop > rect.bottom)
			{
				newTop = rect.bottom - 20;
			}
			(*pDoc->m_nDrag)->setBoundingRect(newLeft, newTop, rect.right, rect.bottom);
			(*pDoc->m_nDrag)->backingStore(pDC);
			(*pDoc->m_nDrag)->drawNew(pDC);
			pDoc->m_bDrawingNewShape = TRUE;
			if ((*pDoc->m_nDrag)->getShapeID() == 3)
			{
				if ((*pDoc->m_nDrag)->getStart() == rect.TopLeft())
				{
					(*pDoc->m_nDrag)->setStart(rect.BottomRight());
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().TopLeft());
				}
				else if ((*pDoc->m_nDrag)->getStart() == rect.BottomRight())
				{
					(*pDoc->m_nDrag)->setEnd(point);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.y += DelY;
					NewEnd.x += DelX;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.x += DelX;
					NewEnd.y += DelY;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
			}
			pDoc->m_Start.x = point.x;
			pDoc->m_Start.y = point.y;
			SetCapture();
			ReleaseDC(pDC);
			return;
		}

		return;
	}
	if (pDoc->m_RESIZE == SHAPE_RESIZELEFT_BOTTOM)
	{
		if (m_bResize == TRUE)
		{
			CRect rect = (*pDoc->m_nDrag)->getBoundingRect();


			int DelX = point.x - pDoc->m_Start.x;
			int DelY = point.y - pDoc->m_Start.y;
			if (pDoc->m_bDrawingNewShape)
			{
				(*pDoc->m_nDrag)->undraw(pDC);
				Invalidate();
			}
			int newLeft = rect.left + DelX;
			int newBottom = rect.bottom + DelY;
			if (newLeft > rect.right)
			{
				newLeft = rect.right - 20;
			}
			if (newBottom < rect.top)
			{
				newBottom = rect.top + 20;
			}
			(*pDoc->m_nDrag)->setBoundingRect(newLeft, rect.top, rect.right, newBottom);

			if ((*pDoc->m_nDrag)->getShapeID() == 3)
			{
				if ((*pDoc->m_nDrag)->getStart() == rect.TopLeft())
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.x += DelX;
					NewEnd.y += DelY;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
				else if ((*pDoc->m_nDrag)->getStart() == rect.BottomRight())
				{
					CPoint NewStart = (*pDoc->m_nDrag)->getStart();
					CPoint NewEnd = (*pDoc->m_nDrag)->getEnd();
					NewStart.y += DelY;
					NewEnd.x += DelX;
					(*pDoc->m_nDrag)->setStart(NewStart);
					(*pDoc->m_nDrag)->setEnd(NewEnd);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					(*pDoc->m_nDrag)->setEnd(point);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					(*pDoc->m_nDrag)->setStart(
													(*pDoc->m_nDrag)->getBoundingRect().left,
													(*pDoc->m_nDrag)->getBoundingRect().bottom
												);
					(*pDoc->m_nDrag)->setEnd(
												(*pDoc->m_nDrag)->getBoundingRect().right,
												(*pDoc->m_nDrag)->getBoundingRect().top
											);
				}
			}
			(*pDoc->m_nDrag)->backingStore(pDC);
			(*pDoc->m_nDrag)->drawNew(pDC);
			pDoc->m_bDrawingNewShape = TRUE;
			pDoc->m_Start.x = point.x;
			pDoc->m_Start.y = point.y;
			SetCapture();
			ReleaseDC(pDC);
			return;
		}

		return;
	}
	if (pDoc->m_RESIZE == SHAPE_DRAG)
	{
		if (pDoc->m_bDragMod == TRUE)
		{
			CRect rect = (*pDoc->m_nDrag)->getBoundingRect();


			int DelX = point.x - pDoc->m_Start.x;
			int DelY = point.y - pDoc->m_Start.y;
			if (pDoc->m_bDrawingNewShape)
			{
				(*pDoc->m_nDrag)->undraw(pDC);
				Invalidate();
			}
			(*pDoc->m_nDrag)->setBoundingRect(rect.left + DelX, rect.top + DelY, rect.right + DelX, rect.bottom + DelY);

			(*pDoc->m_nDrag)->setCurrentPoint(point);

			(*pDoc->m_nDrag)->backingStore(pDC);
			if ((*pDoc->m_nDrag)->getShapeID() == 3)
			{
				if ((*pDoc->m_nDrag)->getStart() == rect.TopLeft())
				{
					(*pDoc->m_nDrag)->setStart((*pDoc->m_nDrag)->getBoundingRect().TopLeft());
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().BottomRight());
				}
				else if ((*pDoc->m_nDrag)->getStart() == rect.BottomRight())
				{
					(*pDoc->m_nDrag)->setStart((*pDoc->m_nDrag)->getBoundingRect().BottomRight());
					(*pDoc->m_nDrag)->setEnd((*pDoc->m_nDrag)->getBoundingRect().TopLeft());
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.right && (*pDoc->m_nDrag)->getStart().y == rect.top)
				{
					(*pDoc->m_nDrag)->setStart(
													(*pDoc->m_nDrag)->getBoundingRect().right,
													(*pDoc->m_nDrag)->getBoundingRect().top
												);
					(*pDoc->m_nDrag)->setEnd(
												(*pDoc->m_nDrag)->getBoundingRect().left,
												(*pDoc->m_nDrag)->getBoundingRect().bottom
											);
				}
				else if ((*pDoc->m_nDrag)->getStart().x == rect.left && (*pDoc->m_nDrag)->getStart().y == rect.bottom)
				{
					(*pDoc->m_nDrag)->setStart(
													(*pDoc->m_nDrag)->getBoundingRect().left,
													(*pDoc->m_nDrag)->getBoundingRect().bottom
												);
					(*pDoc->m_nDrag)->setEnd(
												(*pDoc->m_nDrag)->getBoundingRect().right,
												(*pDoc->m_nDrag)->getBoundingRect().top
											);

				}
			}
			pDoc->m_bDrawingNewShape = TRUE;
			pDoc->m_Start.x = point.x;
			pDoc->m_Start.y = point.y;

			SetCapture();
			ReleaseDC(pDC);
			return;
		}

		return;
	}

	if (nFlags && pDoc->m_RESIZE == SHAPE_NEW)
	{
		auto it = pDoc->m_apShapen.begin();

		pDoc->m_bDrawingNewShape = TRUE;
		if (pDoc->m_bDrawingNewShape == TRUE )
		{
			(*it)->undraw(pDC);
			Invalidate();
		}
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		if (DelX <= 0 && DelY <= 0)
		{
			(*it)->setTopLeft(point.y, point.x);
		}
		else if (DelX >= 0 && DelY >= 0)
		{
			(*it)->setRightBottom(point.x, point.y);
		}
		else if (DelX > 0 && DelY <= 0)
		{
			(*it)->setRightTop(point.x, point.y);

		}
		else if (DelX <= 0 && DelY > 0)
		{
			(*it)->setBottomLeft(point.y, point.x);
		}


		(*it)->backingStore(pDC);
		(*it)->drawNew(pDC);
		(*it)->drawNew(pDC, pDoc->m_Start, point);
		(*it)->setEnd(point);
		ReleaseDC(pDC);
		return;
	}
	CView::OnMouseMove(nFlags, point);
}

void CPaintExView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CDC *MyDC = this->GetDC();
	pDoc->m_bDrawingNewShape = TRUE;
	if (pDoc->m_bDrag && pDoc->m_RESIZE == SHAPE_RESIZERIGHT_BOTTOM)
	{
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
		(*pDoc->m_nDrag)->setBoundingRect(rect.left, rect.top, rect.right + DelX, rect.bottom + DelY);
		delete ((*pDoc->m_nDrag)->m_pBitMap);
		delete ((*pDoc->m_nDrag)->m_pMemDC);
		pDoc->m_bDrag = FALSE;
		pDoc->m_bResize = FALSE;
		pDoc->m_bButtonDown = FALSE;
		Invalidate();
		return;
	}
	else if (pDoc->m_bDrag && (pDoc->m_RESIZE == SHAPE_DRAG))
	{
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
		(*pDoc->m_nDrag)->setBoundingRect(rect.left + DelX, rect.top + DelY, rect.right + DelX, rect.bottom + DelY);
		pDoc->m_bDrag = FALSE;
		delete ((*pDoc->m_nDrag)->m_pBitMap);
		delete ((*pDoc->m_nDrag)->m_pMemDC);
		pDoc->m_bButtonDown = FALSE;
		Invalidate();
		return;
	}
	else if (pDoc->m_bDrag && (pDoc->m_RESIZE == SHAPE_RESIZERIGHT_TOP))
	{
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
		(*pDoc->m_nDrag)->setBoundingRect(rect.left, rect.top + DelY, rect.right + DelX, rect.bottom);
		delete ((*pDoc->m_nDrag)->m_pBitMap);
		delete ((*pDoc->m_nDrag)->m_pMemDC);
		pDoc->m_bDrag = FALSE;
		pDoc->m_bButtonDown = FALSE;
		Invalidate();
		return;
	}
	else if (pDoc->m_bDrag && (pDoc->m_RESIZE == SHAPE_RESIZELEFT_TOP))
	{
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
		(*pDoc->m_nDrag)->setBoundingRect(rect.left + DelX, rect.top + DelY, rect.right, rect.bottom);
		delete ((*pDoc->m_nDrag)->m_pBitMap);
		delete ((*pDoc->m_nDrag)->m_pMemDC);
		pDoc->m_bDrag = FALSE;
		pDoc->m_bButtonDown = FALSE;
		Invalidate();
		return;
	}
	else if (pDoc->m_bDrag && (pDoc->m_RESIZE == SHAPE_RESIZELEFT_BOTTOM))
	{
		int DelX = point.x - pDoc->m_Start.x;
		int DelY = point.y - pDoc->m_Start.y;
		CRect rect = (*pDoc->m_nDrag)->getBoundingRect();
		(*pDoc->m_nDrag)->setBoundingRect(rect.left + DelX, rect.top, rect.right, rect.bottom + DelY);
		delete ((*pDoc->m_nDrag)->m_pBitMap);
		delete ((*pDoc->m_nDrag)->m_pMemDC);
		pDoc->m_bDrag = FALSE;
		pDoc->m_bButtonDown = FALSE;
		Invalidate();
		return;
	}
	if (pDoc->m_RESIZE == SHAPE_NEW && 	pDoc->m_bButtonDown)
	{
		delete ((*pDoc->m_apShapen.begin())->m_pBitMap);
		delete ((*pDoc->m_apShapen.begin())->m_pMemDC);
	}
	pDoc->m_bButtonDown = FALSE;

	Invalidate();
	::ReleaseCapture();
	CView::OnLButtonUp(nFlags, point);
}


void CPaintExView::OnButtonred()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;	
	pDoc->m_LogBrush.lbColor = RGB(255, 0, 0);

}


void CPaintExView::OnUpdateButtonred(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtonblue()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbColor = RGB(0, 0, 255);
	
}


void CPaintExView::OnUpdateButtonblue(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtongreen()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	 if (m_bOnBrush)
		pDoc->m_LogBrush.lbColor = RGB(0, 255, 0);
		m_bOnBrush = false;
}


void CPaintExView::OnUpdateButtongreen(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtonpurple()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbColor = RGB(156, 50, 86);

}


void CPaintExView::OnUpdateButtonpurple(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtonblack()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbColor = RGB(0, 0, 0);
}


void CPaintExView::OnUpdateButtonblack(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtonhue()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CColorDialog p1;
	int iRes = p1.DoModal();
	if (iRes == IDOK)
	{
		pDoc->m_LogBrush.lbColor = p1.GetColor();
		m_bOnBrush = false;	
	}
}


void CPaintExView::OnUpdateButtonhue(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnButtonwhite()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (m_bOnPen)
	{
		pDoc->m_LogPen.lopnColor = RGB(255, 255, 255);
		m_bOnPen = false;
	}
	 if (m_bOnBrush)
	{
		pDoc->m_LogBrush.lbColor = RGB(255, 255, 255);
		m_bOnBrush = false;
	}
}


void CPaintExView::OnUpdateButtonwhite(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}


void CPaintExView::OnShapecircle()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eCirle;
}


void CPaintExView::OnUpdateShapecircle(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eCirle);
}


void CPaintExView::OnShapediamond()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eDiamond;
}


void CPaintExView::OnUpdateShapediamond(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eDiamond);
}


void CPaintExView::OnShapeelip()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eEllipse;
}


void CPaintExView::OnUpdateShapeelip(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eEllipse);
}


void CPaintExView::OnShapehexagon()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eHexagonal;
}


void CPaintExView::OnUpdateShapehexagon(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eHexagonal);
}


void CPaintExView::OnShapeline()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eLine;
}


void CPaintExView::OnUpdateShapeline(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eLine);
}


void CPaintExView::OnShapepentagon()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->ePentagon;
}


void CPaintExView::OnUpdateShapepentagon(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->ePentagon);
}


void CPaintExView::OnShaperoundrect()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eRoundRect;
}


void CPaintExView::OnUpdateShaperoundrect(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eRoundRect);
}


void CPaintExView::OnShapesquare()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eSquare;
}


void CPaintExView::OnUpdateShapesquare(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eSquare);
}


void CPaintExView::OnShapetriangle()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eTriangle;
}

void CPaintExView::OnUpdateShapetriangle(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eTriangle);
}

void CPaintExView::OnShaperect()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eRectangle;
}

void CPaintExView::OnUpdateShaperect(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_eShapeKind == pDoc->eRectangle);
}



void CPaintExView::OnColorbrush()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CColorDialog p1;
	int iRes = p1.DoModal();
	if (iRes == IDOK)
	{
		pDoc->m_LogBrush.lbColor = p1.GetColor();
	}
}

void CPaintExView::OnUpdateColorbrush(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}



void CPaintExView::OnColorpen()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CColorDialog p1;
	int iRes = p1.DoModal();
	if (iRes == IDOK)
	{
		pDoc->m_LogPen.lopnColor = p1.GetColor();
	}
}

void CPaintExView::OnUpdateColorpen(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}

void CPaintExView::OnColorfill()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (!pDoc->m_bFill)
	{
		pDoc->m_bFill = true;
		if (m_bChosingMode)
		{
			m_bChosingMode = false;
		}
	}
	else
	{
		pDoc->m_bFill = false;
	}
}

void CPaintExView::OnUpdateColorfill(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_bFill == true);
}

void CPaintExView::OnModTrash()
{
	// TODO: Add your command handler code here
	if (!m_bDelete)
	{
		m_bDelete = true;
	}
	else
	{
		m_bDelete = false;
	}
}

void CPaintExView::OnUpdateModTrash(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bDelete == true);
}

void CPaintExView::OnShapetext()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	TextInputDlg TXTIN;
	if (TXTIN.DoModal() == IDOK)
	{
		pDoc->m_Text = TXTIN.m_text;
		pDoc->m_eShapeKind = pDoc->eText;
	}
	
}

void CPaintExView::OnUpdateShapetext(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}

void CPaintExView::OnModChoose()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (!m_bChosingMode)
	{
		m_bChosingMode = true;
		if (pDoc->m_bFill)
		{
			pDoc->m_bFill = false;
		}
	}
	else
	{
		m_bChosingMode = false;
	}
}

void CPaintExView::OnUpdateModChoose(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bChosingMode == true);
}

void CPaintExView::OnModResize()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (!m_bResize)
	{
		m_bResize = true;
		pDoc->m_bDragMod = false;
		m_bRot = false;
	}
	else
	{
		m_bResize = false;
	}
}

void CPaintExView::OnUpdateModResize(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bResize == true);
}

void CPaintExView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	return;
	CView::OnLButtonDblClk(nFlags, point);
}

void CPaintExView::OnModDrag()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (!pDoc->m_bDragMod)
	{
		pDoc->m_bDragMod = true;
		m_bResize = false;
		m_bRot = false;
	}
	else
		pDoc->m_bDragMod = false;
}

void CPaintExView::OnUpdateModDrag(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_bDragMod == true);
}

void CPaintExView::OnModRotate()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	
	if (!m_bRot)
	{
		m_bRot = true;
		pDoc->m_bDragMod = false;
		m_bResize = false;
	}
	else
	{
		m_bRot = false;
	}
}


void CPaintExView::OnUpdateModRotate(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(m_bRot == true);
}


void CPaintExView::OnShapecurve()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_eShapeKind = pDoc->eCurve;
}


void CPaintExView::OnUpdateShapecurve(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
}
void CPaintExView::OnUpdateIndicatorPos(CCmdUI *pCmdUI)
{
	CString strPos;
	strPos.Format(_T("(X: %d,Y: %d)"), locationPoint.x, locationPoint.y);
	pCmdUI->Enable();
	pCmdUI->SetText(strPos);
}

void CPaintExView::OnPenbrushSolidpen()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnStyle = PS_SOLID;
}


void CPaintExView::OnUpdatePenbrushSolidpen(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnStyle == PS_SOLID);
}

void CPaintExView::OnPenbrushDashdot()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnStyle = PS_DASHDOT;
}


void CPaintExView::OnUpdatePenbrushDashdot(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnStyle == PS_DASHDOT);
}


void CPaintExView::OnPenbrushDot()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnStyle = PS_DOT;
}


void CPaintExView::OnUpdatePenbrushDot(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnStyle == PS_DOT);
}
void CPaintExView::OnPenbrushDash()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnStyle = PS_DASH;
}


void CPaintExView::OnUpdatePenbrushDash(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnStyle == PS_DASH);
}

void CPaintExView::OnPenbrushHatch2()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbStyle = BS_HATCHED;
	pDoc->m_LogBrush.lbHatch = HS_VERTICAL;
}


void CPaintExView::OnUpdatePenbrushHatch2(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogBrush.lbStyle == BS_HATCHED && pDoc->m_LogBrush.lbHatch == HS_VERTICAL);
}


void CPaintExView::OnPenbrushHatch3()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbStyle = BS_HATCHED;
	pDoc->m_LogBrush.lbHatch = HS_BDIAGONAL;
	
}


void CPaintExView::OnUpdatePenbrushHatch3(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogBrush.lbStyle == BS_HATCHED && pDoc->m_LogBrush.lbHatch == HS_BDIAGONAL);
}


void CPaintExView::OnPenbrushHatch1()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbStyle = BS_HATCHED;
	pDoc->m_LogBrush.lbHatch = HS_CROSS;
}


void CPaintExView::OnUpdatePenbrushHatch1(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogBrush.lbStyle == BS_HATCHED && pDoc->m_LogBrush.lbHatch == HS_CROSS);
	
}

void CPaintExView::OnPenbrushBrushsolid()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogBrush.lbStyle = PS_SOLID;
}


void CPaintExView::OnUpdatePenbrushBrushsolid(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogBrush.lbStyle == PS_SOLID);
}

void CPaintExView::OnPenbrushWidth1()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnWidth.x = 1;
}


void CPaintExView::OnUpdatePenbrushWidth1(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnWidth.x == 1);
}


void CPaintExView::OnPenbrushWidth2()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnWidth.x = 2;
}


void CPaintExView::OnUpdatePenbrushWidth2(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnWidth.x == 2);
}


void CPaintExView::OnPenbrushWidth3()
{
	// TODO: Add your command handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pDoc->m_LogPen.lopnWidth.x = 3;
}


void CPaintExView::OnUpdatePenbrushWidth3(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	CPaintExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	pCmdUI->SetCheck(pDoc->m_LogPen.lopnWidth.x == 3);
}



