
#include "stdafx.h"
#include "C_Triangle.h"
void C_Triangle::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;

	CRect r = getBoundingRect();
	CPoint TPoints[3];
	switch (m_nRotTime)
	{
	case 0:
	{
		TPoints[0].SetPoint(r.left, r.bottom);
		TPoints[1].SetPoint(r.right, r.bottom);
		TPoints[2].SetPoint((r.left + r.right) / 2, r.top);
		
	}
	break;
	case 1:
	{
		TPoints[0].SetPoint(r.left, r.top);
		TPoints[1].SetPoint(r.left, r.bottom);
		TPoints[2].SetPoint(r.right, (r.top + r.bottom) / 2);
	}
	break;
	case 2:
	{
		TPoints[0].SetPoint(r.left, r.top);
		TPoints[1].SetPoint(r.right, r.top);
		TPoints[2].SetPoint((r.left + r.right) / 2, r.bottom);
	}
	break;
	case 3:
	{
		TPoints[0].SetPoint(r.right, r.top);
		TPoints[1].SetPoint(r.right, r.bottom);
		TPoints[2].SetPoint(r.left,(r.top + r.bottom) / 2);
	}
	break;
	}
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Polygon(TPoints, 3);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
void C_Triangle::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	CPoint TPoints[3];
	switch (m_nRotTime)
	{
	case 0:
	{
		TPoints[0].SetPoint(r.left, r.bottom);
		TPoints[1].SetPoint(r.right, r.bottom);
		TPoints[2].SetPoint((r.left + r.right) / 2, r.top);
		pMyDc->Polygon(TPoints, 3);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from device context
	}
	break;
	case 1:
	{
		TPoints[0].SetPoint(r.left, r.top);
		TPoints[1].SetPoint(r.left, r.bottom);
		TPoints[2].SetPoint(r.right,(r.top + r.bottom) / 2);
		pMyDc->Polygon(TPoints, 3);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from 
	}
	break;
	case 2:
	{
		TPoints[0].SetPoint(r.left, r.top);
		TPoints[1].SetPoint(r.right, r.top);
		TPoints[2].SetPoint((r.left + r.right) / 2, r.bottom);
		pMyDc->Polygon(TPoints, 3);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from 
	}
	break;
	case 3:
	{
		TPoints[0].SetPoint(r.right, r.top);
		TPoints[1].SetPoint(r.right, r.bottom);
		TPoints[2].SetPoint(r.left, (r.top + r.bottom) / 2);
		pMyDc->Polygon(TPoints, 3);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from 
	}
	break;
	}
}