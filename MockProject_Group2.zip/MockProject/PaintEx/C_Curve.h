#pragma once
#include "C_Shape.h"
class C_Curve :
	public C_Shape
{
private:
	CPoint Point1;
	CPoint Point2;
	CPoint Point3;
	CPoint Point4;


public:

	int DelPoint2x = 0;
	int DelPoint2y = 0;
	int DelPoint3x = 0;
	int DelPoint3y = 0;

	void drawNew(CDC*, CPoint, CPoint) override;
	void draw(CDC* pMyDc) override
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(m_BoundingRect);
		drawNew(pMyDc, Point1, Point4);
	};
	void drawNew(CDC* pMyDC) override {
		drawNew(pMyDC, Point1, Point4);
	};

};
