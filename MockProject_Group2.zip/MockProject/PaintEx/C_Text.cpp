#include "stdafx.h"
#include "C_Text.h"


C_Text::C_Text()
{
	this->m_ShapeID = 10;
	this->m_nRotTime = 0;
	this->m_bChoose = false;
	this->DisplayedString = _T("");
}


C_Text::~C_Text()
{
	
}

void C_Text::draw(CDC *pMyDc)
{
	CRect rect(200, 100, 300, 200);
	pMyDc->SetTextColor(RGB(255,0,0));
	pMyDc->DrawText(this->DisplayedString,&m_BoundingRect,DT_LEFT);

}
void C_Text::setDisplayedString(CString str)
{
	this->DisplayedString = _T("");
	this->DisplayedString += str;
}
CString C_Text::getDisplayedString()
{
	return this->DisplayedString;
}
void C_Text::drawNew(CDC *pMyDc)
{
	CRect rect(200, 100, 300, 200);
	pMyDc->SetTextColor(RGB(255, 0, 0));
	pMyDc->Rectangle(&m_BoundingRect);
	pMyDc->DrawText(this->DisplayedString, &m_BoundingRect, DT_LEFT);
	
}