#include "stdafx.h"
#include "C_Cirle.h"


void C_Cirle::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	m_BoundingRect.bottom = m_BoundingRect.top + (m_BoundingRect.right - m_BoundingRect.left);
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	/*if(m_bChoose)
		pMyDc->Rectangle(&m_BoundingRect);*/
	
//	pMyDc->SelectObject(pOldPen); // displace drawing objects
//	pMyDc->SelectObject(pOldBrush); // from device context
//	NewPen.CreatePenIndirect(&m_MyLogPen);
//	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	pOldPen = pMyDc->SelectObject(&NewPen);
	//pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Ellipse(&m_BoundingRect);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
	pOldPen->DeleteObject();
	pOldBrush->DeleteObject();
}
void C_Cirle::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	m_BoundingRect.bottom = m_BoundingRect.top + (m_BoundingRect.right - m_BoundingRect.left);
	pMyDc->Ellipse(&m_BoundingRect);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}