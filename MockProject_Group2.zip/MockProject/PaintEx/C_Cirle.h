#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Cirle:
	public C_Shape
{
public:
	C_Cirle()
	{
		m_nRotTime = 0;
		m_ShapeID = 7;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};


