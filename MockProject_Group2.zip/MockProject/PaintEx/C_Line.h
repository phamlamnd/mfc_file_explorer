#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Line : public C_Shape
{
public:
	C_Line()
	{
		m_nRotTime = 0;
		m_ShapeID = 3;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};