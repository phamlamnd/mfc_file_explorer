//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PaintEx.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_INDICATOR_POS                102
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_PaintExTYPE                 130
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDS_EDIT_MENU                   306
#define IDR_TOOLBAR1                    310
#define IDR_TOOLBAR2                    312
#define IDR_TOOLBAR3                    314
#define IDR_TOOLBAR4                    316
#define IDD_DIALOG_TEXTIN               322
#define IDR_TOOLBAR5                    324
#define IDB_BITMAP1                     325
#define IDR_TOOLBAR6                    326
#define IDC_EDIT1                       1004
#define ID_SHAPERECT                    32771
#define ID_SHAPEELIP                    32772
#define ID_SHAPELINE                    32773
#define ID_SHAPESQUARE                  32774
#define ID_SHAPETRIANGLE                32775
#define ID_SHAPECIRCLE                  32776
#define ID_SHAPEDIAMOND                 32777
#define ID_SHAPEPENTAGON                32778
#define ID_SHAPEHEXAGON                 32779
#define ID_SHAPEROUNDRECT               32780
#define ID_BUTTONRED                    32781
#define ID_BUTTONBLUE                   32782
#define ID_BUTTONGREEN                  32783
#define ID_BUTTONPURPLE                 32784
#define ID_BUTTONBLACK                  32785
#define ID_BUTTONWHITE                  32786
#define ID_BUTTONHUE                    32787
#define ID_COLORBRUSH                   32789
#define ID_COLORPEN                     32790
#define ID_COLORFILL                    32791
#define ID_MOD_TRASH                    32792
#define ID_SHAPETEXT                    32794
#define ID_MOD_CHOOSE                   32795
#define ID_MOD_RESIZE                   32796
#define ID_MOD_DRAG                     32797
#define ID_MOD_ROTATE                   32798
#define ID_PENBRUSH_DASH                32799
#define ID_ID_PENBRUSH_DOT              32800
#define ID_ID_PENBRUSH_WIDTH1           32804
#define ID_ID_PENBRUSH_WIDTH3           32806
#define ID_PENBRUSH_HATCH1              32808
#define ID_ID_PENBRUSH_HATCH2           32809
#define ID_ID_PENBRUSH_HATCH3           32810
#define ID_ID_PENBRUSH_DASHDOT          32811
#define ID_ID_PENBRUSH_WIDTH2           32812
#define ID_SHAPECURVE                   32813
#define ID_PENBRUSH_SOLIDPEN            32814
#define ID_PENBRUSH_BRUSHSOLID          32815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        328
#define _APS_NEXT_COMMAND_VALUE         32816
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
