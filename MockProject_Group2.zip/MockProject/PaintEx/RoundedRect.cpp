#include "stdafx.h"
#include "RoundedRect.h"


void C_RoundedRect::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	if (m_bChoose)
	{
		CPen pendot(PS_DASHDOT, 1, RGB(0, 0, 0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
		NewPen.CreatePenIndirect(&m_MyLogPen);
		NewBrush.CreateBrushIndirect(&m_MyLogBrush);
		CPen* pOldPen = pMyDc->SelectObject(&NewPen);
		CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
		CRect r = getBoundingRect();
		CPoint point(r.right / 15, r.bottom / 10);
		pMyDc->RoundRect(&m_BoundingRect, point);
		pMyDc->SelectObject(pOldPen); // displace drawing objects
		pMyDc->SelectObject(pOldBrush); // from device context

}
void C_RoundedRect::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	CRect r = getBoundingRect();
	CPoint point(r.right / 15, r.bottom / 10);
	pMyDc->RoundRect(&m_BoundingRect, point);
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}
