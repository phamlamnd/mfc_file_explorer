#include "stdafx.h"
#include "C_Shape.h"
void C_Shape::backingStore(CDC* pMyDC)
{
	m_pMemDC = new CDC;
	m_pMemDC->CreateCompatibleDC(pMyDC);
	m_pBitMap = new CBitmap;
	CRect r = getBoundingRect();
	m_pBitMap->CreateCompatibleBitmap(pMyDC, abs(r.right - r.left) + 1, abs(r.bottom - r.top) + 1);
	CBitmap *pOldBitmap = m_pMemDC->SelectObject(m_pBitMap);
	m_pMemDC->BitBlt(0, 0, abs(r.right - r.left) + 1, abs(r.bottom - r.top) + 1,
		pMyDC, min(r.left, r.right), min(r.top, r.bottom), SRCCOPY);
	m_pMemDC->SelectObject(pOldBitmap);
	pOldBitmap->DeleteObject();
}
void C_Shape::undraw(CDC *pMyDC)
{
	CRect r = getBoundingRect();
	pMyDC->BitBlt(min(r.left, r.right), min(r.top, r.bottom),
		abs(r.right - r.left) + 1, abs(r.bottom - r.top) + 1, m_pMemDC, 0, 0, SRCCOPY);
	delete m_pBitMap;
	delete m_pMemDC;

}
void C_Shape::setBoundingRect(int left, int top, int right, int bottom)
{
	CRect NewRect(left, top, right, bottom);
	m_BoundingRect = NewRect;
}
CRect C_Shape::getBoundingRect()
{
	return m_BoundingRect;
}
void C_Shape::setRightBottom(int right, int bottom)
{
	m_BoundingRect.right = right;
	m_BoundingRect.bottom = bottom;
}
void C_Shape::setParams(LOGPEN* pPen, LOGBRUSH* pBrush)
{
	m_MyLogPen = *pPen;
	m_MyLogBrush = *pBrush;
}
bool C_Shape::isIn(CPoint point)
{
	if (m_BoundingRect.left < m_BoundingRect.right
		&& ((point.x >= m_BoundingRect.left
			&& point.x <= m_BoundingRect.right
			&& point.y >= m_BoundingRect.top
			&& point.y <= m_BoundingRect.bottom)
			|| (point.x >= m_BoundingRect.left
				&& point.x <= m_BoundingRect.right
				&& point.y < m_BoundingRect.top
				&& point.y >= m_BoundingRect.bottom)))
		return TRUE;
	if ((point.x <= m_BoundingRect.left && point.x >= m_BoundingRect.right
		&& point.y >= m_BoundingRect.top && point.y <= m_BoundingRect.bottom)
		|| (point.x <= m_BoundingRect.top && point.x >= m_BoundingRect.bottom
			&& point.y <= m_BoundingRect.top && point.y >= m_BoundingRect.bottom))
		return true;
	return FALSE;
}
void C_Shape::setTopLeft(int top, int left)
{
	m_BoundingRect.left = left;
	m_BoundingRect.top = top;
}
void C_Shape::setBottomLeft(int bottom, int left)
{
	m_BoundingRect.bottom = bottom;
	m_BoundingRect.left = left;
}
void C_Shape::setRightTop(int right, int top)
{
	m_BoundingRect.right = right;
	m_BoundingRect.top = top;
}
void C_Shape::setBoundingRect(CRect &rect)
{
	this->m_BoundingRect = rect;
}
int C_Shape::getShapeID()
{
	return this->m_ShapeID;
}
void C_Shape::setStart(CPoint point)
{
	this->m_Start = point;
}
void C_Shape::setStart(int x,int y)
{
	this->m_Start.x = x;
	this->m_Start.y = y;
}
void C_Shape::setEnd(CPoint point)
{
	this->m_End = point;
}
void C_Shape::setEnd(int x,int y)
{
	this->m_End.x = x;
	this->m_End.y = y;
}
void C_Shape::setPen(COLORREF penColor, UINT penStyle, POINT penWidth)
{
	this->m_MyLogPen.lopnColor = penColor;
	this->m_MyLogPen.lopnStyle = penStyle;
	this->m_MyLogPen.lopnWidth = penWidth;
}
void C_Shape::setBrush(COLORREF brushColor, ULONG brushHatch, UINT brushStyle)
{
	this->m_MyLogBrush.lbColor = brushColor;
	this->m_MyLogBrush.lbHatch = brushHatch;
	this->m_MyLogBrush.lbStyle = brushStyle;
}


void C_Shape::setnthRepair()
{
	m_nthRepair++;
}
void C_Shape::setCurrentPoint(CPoint point)
{
	m_Current = point;
}