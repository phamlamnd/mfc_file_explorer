#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Hexagonal :
	public C_Shape
{
public:
	C_Hexagonal()
	{
		m_nRotTime = 0;
		m_ShapeID = 5;

		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};
