#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Pentagon : public C_Shape
{
public:
	C_Pentagon()
	{
		m_nRotTime = 0;
		m_ShapeID = 6;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};