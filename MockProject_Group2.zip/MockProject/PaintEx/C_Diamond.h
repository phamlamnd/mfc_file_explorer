#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Diamond :
	public C_Shape
{
public:
	C_Diamond()
	{
		m_nRotTime = 0;
		m_ShapeID = 4;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};
