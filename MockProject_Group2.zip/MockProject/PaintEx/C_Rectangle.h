#pragma once
#include "C_Shape.h"
#include "stdafx.h"
class C_Rectangle : public C_Shape
{
public:
	C_Rectangle()
	{
		m_ShapeID = 0;
		m_nRotTime = 0;
		m_bChoose = false;
	}
	virtual void draw(CDC*);
	virtual void drawNew(CDC*);
};
