#include "stdafx.h"
#include "C_Ellipse.h"

void C_Ellipse::draw(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;


	if(m_bChoose)
	{
		CPen pendot(PS_DASHDOT,1,RGB(0,0,0));
		pMyDc->SelectStockObject(NULL_BRUSH);
		pMyDc->SelectObject(&pendot);
		pMyDc->Rectangle(&m_BoundingRect);
	}
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	NewPen.CreatePenIndirect(&m_MyLogPen);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Ellipse(&m_BoundingRect);
	
	pMyDc->SelectObject(pOldPen); // displace drawing objects
	pMyDc->SelectObject(pOldBrush); // from device context
}

void C_Ellipse::drawNew(CDC* pMyDc)
{
	CPen NewPen;
	CBrush NewBrush;
	NewPen.CreatePenIndirect(&m_MyLogPen);
	NewBrush.CreateBrushIndirect(&m_MyLogBrush);
	CPen* pOldPen = pMyDc->SelectObject(&NewPen);
	CBrush* pOldBrush = pMyDc->SelectObject(&NewBrush);
	pMyDc->Ellipse(&m_BoundingRect);
	pMyDc->SelectObject(pOldPen);
	pMyDc->SelectObject(pOldBrush);
}