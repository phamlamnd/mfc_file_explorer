
// PaintExDoc.h : interface of the CPaintExDoc class
//


#pragma once
#include <iostream>
#include<vector>
#include "C_Ellipse.h"
#include "C_Line.h"
#include "C_Pentagon.h"
#include "C_Rectangle.h"
#include "C_Triangle.h"
#include "C_Square.h"
#include "RoundedRect.h"
#include "C_Cirle.h"
#include "C_Hexagonal.h"
#include "C_Diamond.h"
#include "C_Text.h"
#include "C_Curve.h"

class CPaintExDoc : public CDocument
{
protected: // create from serialization only
	CPaintExDoc();
	DECLARE_DYNCREATE(CPaintExDoc)

// Attributes
public:
	bool m_bFill;
	bool m_bDragMod;
	CPoint m_Start;
	BOOL m_bDrag;
	int m_nShape;
	CString m_Text;
	std::vector<C_Shape*>::iterator m_nDrag;
	BOOL m_bButtonDown;
	int m_BkMode;
	LOGPEN m_LogPen;
	LOGBRUSH m_LogBrush;
	enum EnumShape { eRectangle, eEllipse, eTriangle, ePentagon, eLine, eSquare, eHexagonal, eCirle, eDiamond, eRoundRect,eText, eCurve };
	EnumShape m_eShapeKind;
	//C_Shape *m_apShape[MAX_SHAPES];
	std::vector<C_Shape*> m_apShapen;
	int m_FastRedrawMode;
	enum Modify { eDrag, eRBottom, eRTop, eLBottom, LBottom };
	bool m_bResize;
	BOOL m_bDrawingNewShape;
	int m_RESIZE;
// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CPaintExDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
