#pragma once
#include<iostream>

#include <vector>
#include<afxwin.h>

using namespace std;

class C_Shape
{
protected:
	CRect m_BoundingRect;
	int m_ShapeID;
	CPoint m_Start, m_End;
	LOGPEN m_MyLogPen;
	LOGBRUSH m_MyLogBrush;
	CString DisplayedString;
public:
	virtual ~C_Shape() {}
	bool m_bChoose;
	int getShapeID();
	void setStart(CPoint point);
	void setEnd(CPoint point);
	void setStart(int x, int y);
	void setEnd(int x, int y);
	CPoint getStart() { return this->m_Start; }
	CPoint getEnd() { return this->m_End; }
	int m_nRotTime;
	LOGPEN getLogPen() { return this->m_MyLogPen; }
	void setPen(COLORREF penColor, UINT penStyle, POINT penWidth);
	LOGBRUSH getLogBrush() { return this->m_MyLogBrush; }
	void setBrush(COLORREF brushColor, ULONG brushHatch, UINT brushStyle);
	LOGFONT m_font;
	void setBoundingRect(int left, int top, int right, int bottom);
	void setBoundingRect(CRect &rect);
	CRect getBoundingRect();
	void setRightBottom(int right, int bottom);
	void setTopLeft(int top, int left);
	void setBottomLeft(int bottom, int left);
	void setRightTop(int right, int top);
	void setParams(LOGPEN *, LOGBRUSH *);
	virtual void draw(CDC *) = 0;
	virtual void drawNew(CDC*) = 0;
	void backingStore(CDC *);
	void undraw(CDC *);
	CDC* m_pMemDC;
	CBitmap* m_pBitMap;
	bool isIn(CPoint point);
	virtual void setDisplayedString(CString str) {}
	virtual CString getDisplayedString() { return this->DisplayedString; }
	virtual void drawNew(CDC*, CPoint, CPoint) {};
	virtual void setCount() {};
	CPoint m_Current;
	int m_nthRepair = 0;
	void setnthRepair();
	void setCurrentPoint(CPoint point);
};
//class C_Text :public C_Shape
//{
//private:
//	int textWidth, textHeight, maxTextWidth;
//	bool AddChar(int c);
//	bool AddNewLine();
//	bool Backspace();
//	bool Del();
//public:
//	vector<string> text;
//	POINT tailPos;  //tailPos is the last char position of text vector
//	POINT caretPos; //carerPos is calculated from inputPos
//	POINT inputPos; //inputPos is related to text vector
//	C_Text();
//	virtual ~C_Text();
//	virtual void Draw(CDC*);
//	void ResizingText(int mouseX, int mouseY, int mode);
//	bool CheckTextBoxBigEnough(int X, int Y);
//	void CalculateCaretPosition();
//	void Moving(int mouseX, int mouseY);
//};