
// FileExplorer_Group1Dlg.h : header file
//

#pragma once
#include "afxshelltreectrl.h"
#include "afxshelllistctrl.h"
#include "afxwin.h"
#include "PropertiesDlg.h"
#include "AboutDlg.h"
#include "RenameDialog.h"
#include "FileOperations.h"
#include <vector>
//Declare Current file and folder properties
struct CurrentUrlInfo
{
	CString g_name;
	CString g_type;
	CString g_size;
	CString g_path;
};

#define MODIFY_NONE					0
#define MODIFY_CUT					1
#define MODIFY_COPY					2
#define MODIFY_PASTE				4
#define MODIFY_ITEM_TREE_CLICK		8
#define MODIFY_ITEM_LIST_CLICK		16

struct ModifyInfo
{
	int IsCut;
	int IsCopy;
	int IsPaste;
	int IsItemTreeClick;
	int IsItemListClick;
	CString src_path;
	CString src_name;
	CString des_path;
	CString des_name;

	std::vector<CString> src_path_;
	std::vector<CString> src_name_;
};

extern CurrentUrlInfo urlInfo;
extern ModifyInfo modifyInfo;

// CFileExplorer_Group1Dlg dialog
class CFileExplorer_Group1Dlg : public CDialogEx
{
// Construction
public:
	CFileExplorer_Group1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FILEEXPLORER_GROUP1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	void OnOK(); //override OnOK()
	CMFCShellTreeCtrl shell_tree; //Shell Tree
	CMFCShellListCtrl shell_list; //Shell List
	CComboBox combo_box_path; 
	CComboBox combo_box_view;
	CButton button_go;
	CButton button_search;
	CEdit edit_search;
	CButton button_foward;
	CButton button_back;
	CListBox count_item;
	CStatusBar m_bar; //status bar
public:
	void getSizeFolder(CString strPath); //get size folder
	afx_msg void OnNMClickMfcshelltree1(NMHDR *pNMHDR, LRESULT *pResult); //Click on shell tree and display on shell list and combobox
	afx_msg void OnLvnItemActivateMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //double click on shell list and display on combobox
	afx_msg void OnCbnSelchangeComboBoxView(); //View select on combobox
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/); //ShellList Right click menu
	afx_msg void OnMenuHelpAbout(); //Dialog About
	afx_msg void OnMenuViewTiles(); //Select View Tiles on Menu 
	afx_msg void OnMenuViewIcons(); //Select View Icon on Menu 
	afx_msg void OnMenuViewList(); //Select View List on Menu 
	afx_msg void OnMenuViewDetails(); //Select View Details on Menu 
	afx_msg void OnMenuFileNewFloder(); //Menu new folder
	afx_msg void OnMenuFileNewTextdocument(); //Menu new doccument
	afx_msg void OnMenuFileOpen(); //Menu open folder
	afx_msg void OnMenuFileDelete(); //Menu delete
	afx_msg void OnMenuFileRename(); //Menu rename
	afx_msg void OnMenuFileProperties(); //Menu properties
	afx_msg void OnMenuFileClose(); //Menu close
	afx_msg void OnBnClickedGo(); //button go
	afx_msg void OnBnClickedButtonBack(); //Back button
	afx_msg void OnBnClickedButtonFoward(); //Foward button
	afx_msg void OnPopupMenuListViewTiles(); //Popup Menu view tiles
	afx_msg void OnPopupMenuListViewIcons(); //Popup Menu view icons
	afx_msg void OnPopupMenuListViewList(); //Popup Menu view list
	afx_msg void OnPopupMenuListViewDetails(); //Popup Menu view details
	afx_msg void OnPopupMenuListRefresh(); //Popup menu refresh
	afx_msg void OnPopupMenuListProperties(); //Popup menu properties
	afx_msg void OnPopupMenuListCut(); //Popup menu cut 
	afx_msg void OnPopupMenuListCopy(); //Popup menu copy 
	afx_msg void OnPopupMenuListPaste(); //Popup menu paste
	afx_msg void OnPopupMenuListDelete(); //Popup menu delete
	afx_msg void OnPopupMenuListRename(); //Popup menu rename
	afx_msg void OnPopupMenuListNewFolder(); //Popup menu new folder
	afx_msg void OnPopupMenuListNewTextdocument(); //popup menu new text document
	afx_msg void OnPopupMenuListOpen(); //PopupMenu open folder
	afx_msg void OnPopupMenuTreeOpen(); //ShellTree popup menu open
	afx_msg void OnPopupMenuTreeCut(); //ShellTree popup menu cut
	afx_msg void OnPopupMenuTreeCopy(); //ShellTree popup menu copy
	afx_msg void OnPopupMenuTreePaste(); //ShellTree popup menu paste
	afx_msg void OnPopupMenuTreeDelete(); //ShellTree popup menu delete
	afx_msg void OnPopupMenuTreeRename(); //ShellTree popup menu rename
	afx_msg void OnPopupMenuTreeProperties(); //ShellTree popup menu properties
	afx_msg void OnMenuEditCut(); //Cut on menu
	afx_msg void OnMenuEditCopy(); //copy on menu
	afx_msg void OnMenuEditPaste(); //paste on menu
	afx_msg void OnLvnKeydownMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //Short key Ctrl+C, Ctrl+X, Ctrl+V, Ctrl+O, F2, F5
	afx_msg void OnLvnBeginlabeleditMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //begin change list item
	afx_msg void OnLvnEndlabeleditMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //end change list item
	afx_msg void OnEnChangeEditSearch(); //Search
	afx_msg void OnNMRClickMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //check left click item on shell list
	afx_msg void OnNMClickMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult); //check right click item on shell list
	afx_msg void OnTvnBeginlabeleditMfcshelltree1(NMHDR *pNMHDR, LRESULT *pResult); //begin edit item on tree
	afx_msg void OnTvnEndlabeleditMfcshelltree1(NMHDR *pNMHDR, LRESULT *pResult); //end edit item on tree
	afx_msg void OnTvnKeydownMfcshelltree1(NMHDR *pNMHDR, LRESULT *pResult); //short key on tree
	afx_msg void OnSize(UINT nType, int cx, int cy); //auto resizing status bar
	afx_msg void OnTimer(UINT_PTR nIDEvent); //update status bar
	afx_msg void OnTvnSelchangingMfcshelltree1(NMHDR *pNMHDR, LRESULT *pResult); //check click on tree item
	afx_msg void OnLvnBegindragMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnHdnEnddragMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnHdnBegindragMfcshelllist1(NMHDR *pNMHDR, LRESULT *pResult);
};