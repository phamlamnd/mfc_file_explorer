// PropertiesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FileExplorer_Group1.h"
#include "PropertiesDlg.h"
#include "afxdialogex.h"
#include "FileExplorer_Group1Dlg.h"

// PropertiesDlg dialog

IMPLEMENT_DYNAMIC(PropertiesDlg, CDialogEx)

PropertiesDlg::PropertiesDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_PROPERTIES, pParent)
{

}

PropertiesDlg::~PropertiesDlg()
{
}

void PropertiesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_PROPERTIES_DLG_NAME, edit_properties_name);
	DDX_Control(pDX, IDC_STATIC_PROPERTIES_TYPE, edit_properties_type);
	DDX_Control(pDX, IDC_STATIC_PROPERTIES_SIZE, edit_properties_size);
	DDX_Control(pDX, IDC_STATIC_PROPERTIES_PATH, edit_properties_path);
}


BEGIN_MESSAGE_MAP(PropertiesDlg, CDialogEx)
END_MESSAGE_MAP()

BOOL PropertiesDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	edit_properties_name.SetWindowText(urlInfo.g_name);
	edit_properties_path.SetWindowText(urlInfo.g_path);
	return TRUE;
}
